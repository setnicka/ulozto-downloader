__version__ = '2.6.0'
__git_version__ = ''
